﻿using KvalitetVazduha.Models;
using KvalitetVazduha.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reactive.Linq;
using System.Reactive.Threading.Tasks;
using System.Threading.Tasks;

namespace KvalitetVazduha.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class KvalitetVazduhaController : ControllerBase
    {
        private readonly OpenMeteoService _openMeteoService;

        public KvalitetVazduhaController(OpenMeteoService openMeteoService)
        {
            _openMeteoService = openMeteoService ?? throw new ArgumentNullException(nameof(openMeteoService));
        }

        [HttpGet]
        public async Task<IActionResult> Get(double latitude, double longitude)
        {
            try
            {
                var airQualityData = await _openMeteoService.GetAirQualityData(latitude, longitude).ToTask();
                return Ok(airQualityData);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
