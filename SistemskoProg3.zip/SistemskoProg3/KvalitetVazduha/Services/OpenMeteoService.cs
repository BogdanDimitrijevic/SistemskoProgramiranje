﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Reactive.Linq;
using System.Threading.Tasks;
using KvalitetVazduha.Models;

namespace KvalitetVazduha.Services
{
    public class OpenMeteoService
    {
        private readonly HttpClient _httpClient;

        public OpenMeteoService(HttpClient httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        }

        public IObservable<KvalitetVazduhaModel> GetAirQualityData(double latitude, double longitude)
        {
            
            var url = $"?latitude={latitude}&longitude={longitude}&hourly=pm10,pm2_5,carbon_monoxide,nitrogen_dioxide";

            

            return Observable.FromAsync(() => GetAirQualityAsync(url));
        }

        private async Task<KvalitetVazduhaModel> GetAirQualityAsync(string url)
        {
            try
            {
                var response = await _httpClient.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    var errorMessage = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Error fetching air quality data: {response.StatusCode} ({response.ReasonPhrase}): {errorMessage}");
                }

                return await response.Content.ReadFromJsonAsync<KvalitetVazduhaModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching air quality data: {ex.Message}");
            }
        }
    }
}
