﻿
namespace KvalitetVazduha.Models;

public class KvalitetVazduhaModel
{
    public double latitude { get; set; }
    public double longitude { get; set; }
    public double generationtime_ms { get; set; }
    public int utc_offset_seconds { get; set; }
    public string timezone { get; set; }
    public string timezone_abbreviation { get; set; }
    public double elevation { get; set; }
    public HourlyUnits hourly_units { get; set; }
    public Hourly hourly { get; set; }

    public class HourlyUnits
    {
        public string pm10 { get; set; }
        public string pm2_5 { get; set; }
        public string carbon_monoxide { get; set; }
        public string nitrogen_dioxide { get; set; }
    }

    public class Hourly
    {
        public List<string> time { get; set; }
        public List<float> pm10 { get; set; }
        public List<float> pm2_5 { get; set; }
        public List<float> carbon_monoxide { get; set; }
        public List<float> nitrogen_dioxide { get; set; }
    }
}
